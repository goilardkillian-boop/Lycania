scoreboard objectives add poule_ponte dummy
scoreboard objectives add vache_lait dummy
scoreboard objectives add lait_dette dummy
scoreboard objectives add lait_delai dummy
scoreboard objectives add ponte_jour dummy
scoreboard players add #jour ponte_jour 0
scoreboard players add #dernier ponte_jour 0
scoreboard players add #tmp ponte_jour 0
scoreboard players add #fait ponte_jour 0
