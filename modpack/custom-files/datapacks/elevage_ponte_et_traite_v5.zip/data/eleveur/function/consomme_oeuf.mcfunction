# Execute en tant que la poule
scoreboard players remove @s poule_ponte 1
tag @e[type=minecraft:item,tag=ponte_candidat,distance=..4,limit=1,sort=nearest] add ponte_ok
tag @e[type=minecraft:item,tag=ponte_candidat,distance=..4,limit=1,sort=nearest] remove ponte_candidat
