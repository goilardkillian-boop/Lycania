# Execute en tant que le joueur. Retire un seau de lait, puis se rappelle
# tant qu'il reste de la dette. Le tag #meadow:wooden_milk_bucket couvre
# les sept laits de Meadow : vache, mouton, chevre, bufflonne, grain,
# amethyste et warped.
scoreboard players set #fait ponte_jour 0

execute if items entity @s weapon.mainhand minecraft:milk_bucket run function eleveur:swap_main
execute if score #fait ponte_jour matches 0 if items entity @s weapon.offhand minecraft:milk_bucket run function eleveur:swap_off
execute if score #fait ponte_jour matches 0 if items entity @s weapon.mainhand #meadow:wooden_milk_bucket run function eleveur:swap_main_bois
execute if score #fait ponte_jour matches 0 if items entity @s weapon.offhand #meadow:wooden_milk_bucket run function eleveur:swap_off_bois
execute if score #fait ponte_jour matches 0 run function eleveur:refus_inventaire

execute if score #fait ponte_jour matches 0 run scoreboard players set @s lait_dette 0
execute if score #fait ponte_jour matches 1 run scoreboard players remove @s lait_dette 1
execute if score @s lait_dette matches 1.. run function eleveur:rembourse
