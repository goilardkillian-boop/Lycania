# Ponte du jour : 1 oeuf par defaut, parfois 2, parfois aucun
scoreboard players set @s poule_ponte 1
execute if predicate eleveur:chance_15 run scoreboard players set @s poule_ponte 2
execute unless score @s poule_ponte matches 2 if predicate eleveur:chance_20 run scoreboard players set @s poule_ponte 0
tag @s add ponte_init
