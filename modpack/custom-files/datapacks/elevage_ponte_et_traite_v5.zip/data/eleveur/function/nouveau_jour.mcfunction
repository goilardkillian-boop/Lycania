scoreboard players operation #dernier ponte_jour = #jour ponte_jour
execute as @e[type=minecraft:chicken] run function eleveur:tirage_poule
execute as @e[type=#eleveur:laitieres] run function eleveur:tirage_vache
