# Nouveau jour : on retire les quotas
execute store result score #jour ponte_jour run time query day
execute unless score #jour ponte_jour = #dernier ponte_jour run function eleveur:nouveau_jour

# Filtrage des oeufs pondus au sol
execute as @e[type=minecraft:item,nbt={Item:{id:"minecraft:egg"}},tag=!ponte_ok] at @s unless data entity @s Thrower run function eleveur:filtre_oeuf

# Comptes a rebours de correction de traite
execute as @a[scores={lait_delai=1..}] run function eleveur:decompte
