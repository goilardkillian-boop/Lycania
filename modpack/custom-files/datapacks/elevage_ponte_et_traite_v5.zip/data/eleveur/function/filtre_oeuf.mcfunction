# Execute en tant que l'oeuf, a sa position

# Aucune poule autour : ce n'est pas une ponte (coffre casse, loot, etc.)
execute unless entity @e[type=minecraft:chicken,distance=..3] run return run tag @s add ponte_ok

# Poules jamais vues : on leur tire leur quota du jour
execute as @e[type=minecraft:chicken,distance=..3,tag=!ponte_init] run function eleveur:tirage_poule

# On cherche une poule ayant encore du quota
tag @s add ponte_candidat
execute as @e[type=minecraft:chicken,distance=..3,scores={poule_ponte=1..},limit=1,sort=nearest] at @s run function eleveur:consomme_oeuf

# Toujours candidat : personne n'avait de quota, l'oeuf disparait
execute if entity @s[tag=ponte_candidat] run kill @s
tag @s remove ponte_candidat
