# Execute en tant que le joueur qui vient d'utiliser un seau sur une bete
advancement revoke @s only eleveur:traite

# Aucune laitiere a portee : rien a controler
execute unless entity @e[type=#eleveur:laitieres,distance=..5] run return 0

# Bete jamais vue : on lui tire son quota du jour
execute as @e[type=#eleveur:laitieres,distance=..5,tag=!lait_init,limit=1,sort=nearest] run function eleveur:tirage_vache

# Bete ayant encore du quota : on decremente et on laisse passer
execute as @e[type=#eleveur:laitieres,distance=..5,scores={vache_lait=1..},limit=1,sort=nearest] run return run scoreboard players remove @s vache_lait 1

# Refus : on empile une dette et on relance le compte a rebours
scoreboard players add @s lait_dette 1
scoreboard players set @s lait_delai 4
tellraw @s [{"text":"[Élevage] ","color":"gold"},{"text":"Cette bête est déjà traite pour aujourd'hui. Laisse-lui la nuit.","color":"gray"}]
