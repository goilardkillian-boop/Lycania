item replace entity @s weapon.offhand with meadow:wooden_bucket
scoreboard players set #fait ponte_jour 1
