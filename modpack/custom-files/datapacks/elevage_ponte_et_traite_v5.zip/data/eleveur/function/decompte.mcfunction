scoreboard players remove @s lait_delai 1
execute if score @s lait_delai matches 0 run function eleveur:rembourse
