execute store result score #tmp ponte_jour run clear @s minecraft:milk_bucket 1
execute if score #tmp ponte_jour matches 1.. run give @s minecraft:bucket 1
execute if score #tmp ponte_jour matches 1.. run scoreboard players set #fait ponte_jour 1
execute if score #fait ponte_jour matches 0 store result score #tmp ponte_jour run clear @s #meadow:wooden_milk_bucket 1
execute if score #tmp ponte_jour matches 1.. if score #fait ponte_jour matches 0 run give @s meadow:wooden_bucket 1
execute if score #tmp ponte_jour matches 1.. if score #fait ponte_jour matches 0 run scoreboard players set #fait ponte_jour 1
