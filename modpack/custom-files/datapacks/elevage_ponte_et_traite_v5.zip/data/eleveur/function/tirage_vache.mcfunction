# Traite du jour : 2 seaux par defaut, parfois 3, parfois 1
scoreboard players set @s vache_lait 2
execute if predicate eleveur:chance_20 run scoreboard players set @s vache_lait 3
execute unless score @s vache_lait matches 3 if predicate eleveur:chance_25 run scoreboard players set @s vache_lait 1
tag @s add lait_init
