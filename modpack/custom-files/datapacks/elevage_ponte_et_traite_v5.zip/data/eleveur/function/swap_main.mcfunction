item replace entity @s weapon.mainhand with minecraft:bucket
scoreboard players set #fait ponte_jour 1
