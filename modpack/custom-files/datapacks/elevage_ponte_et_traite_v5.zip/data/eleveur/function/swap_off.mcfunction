item replace entity @s weapon.offhand with minecraft:bucket
scoreboard players set #fait ponte_jour 1
